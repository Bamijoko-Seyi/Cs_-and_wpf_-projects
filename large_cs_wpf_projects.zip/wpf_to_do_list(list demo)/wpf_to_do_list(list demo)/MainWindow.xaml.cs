﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf_to_do_list_list_demo_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void add_button_Click(object sender, RoutedEventArgs e)
        {
            list_entry.Items.Add(main_text_box.Text);
        }

        private void del_button_Click(object sender, RoutedEventArgs e)
        {
            var items = list_entry.SelectedItems;
            var items_list = new ArrayList(items);
            foreach(var item in items_list)
            {
                list_entry.Items.Remove(item);
            }
            //objext index = list_entry.SelectedItem;
            //var result = MessageBox.Show("Are you sure you want to remove this task?","Delete Task?" )
            //list_entry.Items.Remove(object);
            //allow the enter button functionality to add items
        }

        private void clr_button_Click(object sender, RoutedEventArgs e)
        {
            list_entry.Items.Clear();
        }
    }
}
