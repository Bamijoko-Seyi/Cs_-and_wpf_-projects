﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Wpf_first_testing
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int tracker = 0;
        public MainWindow()
        {
            InitializeComponent();
            tracker = 0;
        }

        private void hello_button_Click(object sender, RoutedEventArgs e)
        {
            if(tracker == 0)
            {
                hello_txt.Text = "...";
                tracker++;
            }
            else if(tracker == 1)
            {
                hello_txt.Text = "I told you not to press it";
                tracker++;
            }
            else if (tracker == 2)
            {
                hello_txt.Text = "You are a stubborn one, aren't you";
                tracker++;
            }

            else if (tracker == 3)
            {
                hello_txt.Text = "Please...";
                tracker++;
            }

            else if (tracker == 4)
            {
                hello_txt.Text = "...";
                tracker++;
            }
            else if (tracker == 10)
            {
                hello_txt.Text = "....";
                tracker++;
            }
            else if (tracker == 20)
            {
                hello_txt.Text = "You are wasting your time lol";
                tracker++;
            }

            else if (tracker == 21)
            {
                hello_txt.Text = "I'm warning you for the last time";
                tracker++;
            }

            else if (tracker == 22)
            {
                hello_txt.Text = "Last chance!";
                tracker++;
            }
            else if (tracker == 23)
            {
                hello_txt.Text = "There!!! Try clicking the button now lol";
                hello_button.Width = 10;
                hello_button.Height = 5;
                tracker++;
            }
            else if (tracker == 24)
            {
                hello_txt.Text = "...";
                hello_button.Width = 100;
                hello_button.Height = 50;
                tracker++;
            }
            else if (tracker == 25)
            {
                hello_txt.Text = "CAN YOU STOP?";
                tracker++;
            }

            else if (tracker == 26)
            {
                hello_txt.Text = "You know what?";
                tracker++;
            }

            else if (tracker == 27)
            {
                hello_txt.Text = "I give up lol";
                tracker++;
            }

            else if (tracker == 28)
            {
                this.Close();
                tracker++;
            }

            else
            {
                tracker++;
            }
        }
    }
}
