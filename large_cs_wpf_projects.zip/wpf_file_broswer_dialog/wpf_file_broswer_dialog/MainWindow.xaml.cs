﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using Winforms = System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf_file_broswer_dialog
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Winforms.FolderBrowserDialog dialog = new Winforms.FolderBrowserDialog();
            dialog.InitialDirectory = "C:\\Users\\user\\Documents\\Books";
            Winforms.DialogResult dialogResult = dialog.ShowDialog();
            if(dialogResult == Winforms.DialogResult.OK)
            {
                string folder = dialog.SelectedPath;
                result_textbox.Text = folder;
            }
        }
    }
}
