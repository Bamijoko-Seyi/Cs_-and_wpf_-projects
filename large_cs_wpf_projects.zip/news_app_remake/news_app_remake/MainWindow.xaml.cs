﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using news_app_remake.User_control.New_item;
using Newtonsoft.Json;
using System.Diagnostics;

namespace MahApps.Metro.Simple.Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Controls.MetroWindow
    {
        private List<string> articleTitles;
        public MainWindow()
        {
            InitializeComponent();
            articleTitles = new List<string>();
            PopulateStackPanel("world",MainPanel);
        }

        private void PopulateStackPanel(string Category, StackPanel panel_name)
        {
            const string apiKey = "87e23dd9778fd8fa32cf1007bef612bd";
            string apiUrl = "https://gnews.io/api/v4/top-headlines?category=";
            string category = Category; // Example query, modify as needed

            string fullUrl = $"{apiUrl}{category}&lang=en&max=20&token={apiKey}";
            string jsonResponse;

            using (WebClient client = new WebClient())
            {
                try
                {
                    jsonResponse = client.DownloadString(fullUrl);
                    dynamic data = JsonConvert.DeserializeObject(jsonResponse);
                    List<dynamic> articles = data["articles"].ToObject<List<dynamic>>();

                    foreach (var article in articles)
                    {
                        string title = article["title"];
                        string description = article["description"];
                        string imageUrl = article["image"];
                        string articleUrl = article["url"];
                        string datePublished = article["publishedAt"];
                        //string date_ago = GetTimeAgo(datePublished);

                        articleTitles.Add(title); // Store the title

                        UserControl1 userControl = new UserControl1();
                        userControl.Article_title_PH = title;
                        Uri imageUri = new Uri(imageUrl, UriKind.Absolute);
                        BitmapImage imageSource = new BitmapImage(imageUri);
                        userControl.Source_image_PH = imageSource;
                        userControl.Margin = new Thickness(20);
                        userControl.Url = articleUrl;
                        //userControl.pulish_date.Text = date_ago;

                        userControl.MouseLeftButtonUp += (sender, e) =>
                        {
                            try
                            {
                                Process.Start(new ProcessStartInfo
                                {
                                    FileName = userControl.Url,
                                    UseShellExecute = true
                                });
                            }
                            catch (Exception ex)
                            {
                                // Handle any exceptions that occur
                                Console.WriteLine("Error opening URL: " + ex.Message);
                            }

                            e.Handled = true;
                        };

                        panel_name.Children.Add(userControl);
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that may occur during the request or data parsing.
                    Console.WriteLine($"An error occurred: {ex.Message}");
                }
            }
        }
    }
}
