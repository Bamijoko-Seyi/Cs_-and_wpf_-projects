﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace wpf_open_file_dialog
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void fire_button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog file_path = new OpenFileDialog();
            file_path.Filter = "Choose a .png file | *.png";
            file_path.Title = ".png selecetor";
            bool? success = file_path.ShowDialog();
            //file_path.Multiselect = true;
            if(success == true)
            {
                string path = file_path.SafeFileName;
                result_text_box.Text = path;
            }
            else
            {
                result_text_box.Text = "File access failed!";
            }

        }
    }
}
