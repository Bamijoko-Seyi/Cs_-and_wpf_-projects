﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf_custom_textbox__controls.New.UserControls
{
    /// <summary>
    /// Interaction logic for ClearableTextbox.xaml
    /// </summary>
    public partial class ClearableTextbox : UserControl
    {
        public ClearableTextbox()
        {
            InitializeComponent();
        }
        private string placeholder;
        public string Placeholder
        {
            get { return placeholder;}
            set { placeholder = value;
                tb_place_holder.Text = placeholder;
            }
        }
        private void clear_click(object sender, RoutedEventArgs e)
        {
            txt_input.Clear();
            txt_input.Focus();
        }

        private void txt_input_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(txt_input.Text))
            {
                tb_place_holder.Visibility = Visibility.Visible;
            }
            else
            {
                tb_place_holder.Visibility = Visibility.Hidden;
            }
        }
    }
}
